package me.skaffy.client.water;

import com.mojang.blaze3d.platform.InputConstants;
import me.skaffy.RealisticWater;
import me.skaffy.block.SourceBlock;
import me.skaffy.net.SourceToggleAllPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

public final class AguaKeys {
    private static KeyMapping keyCloseAll;
    private static KeyMapping keyInteractRemote;
    private static KeyMapping keyOpenAll;
    private static KeyMapping keyEmergencyClear;
    private static KeyMapping keyGuide;

    private AguaKeys() {}

    public static void register() {
        KeyMapping.Category category = KeyMapping.Category.register(RealisticWater.id("realistic_fluids"));

        keyCloseAll = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.realistic-water.close_all_sources", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F, category));

        keyInteractRemote = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.realistic-water.interact_remote", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        keyOpenAll = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.realistic-water.open_all_sources", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, category));

        keyEmergencyClear = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.realistic-water.emergency_clear", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, category));

        keyGuide = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.realistic-water.guide", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, category));

        ClientTickEvents.END_CLIENT_TICK.register(AguaKeys::tick);
    }

    private static void tick(Minecraft mc) {
        while (keyGuide.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new ModGuideScreen(null));
            }
        }

        while (keyCloseAll.consumeClick()) {
            sources(mc, 6, 0);
            if (mc.player != null) {
                mc.player.sendOverlayMessage(Component.translatable("realistic-water.sources.closed_all"));
            }
        }

        while (keyInteractRemote.consumeClick()) {
            interactRemote(mc);
        }

        while (keyOpenAll.consumeClick()) {
            sources(mc, 6, 1);
            if (mc.player != null) {
                mc.player.sendOverlayMessage(Component.translatable("realistic-water.sources.opened_all"));
            }
        }

        while (keyEmergencyClear.consumeClick()) {
            clearAllEmergency(mc);
        }
    }

    private static void interactRemote(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;

        HitResult hit = mc.player.pick(64.0D, 0.0F, false);
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
            BlockPos pos = blockHit.getBlockPos();
            BlockState state = mc.level.getBlockState(pos);
            if (state.getBlock() instanceof SourceBlock) {
                SourceScreen.openNextTick(pos, state);
                mc.player.sendOverlayMessage(Component.translatable("block.realistic-water.source.remote_opened"));
                return;
            }
        }
        mc.player.sendOverlayMessage(Component.translatable("block.realistic-water.source.remote_miss"));
    }

    public static void sources(Minecraft mc, int kind, int mode) {
        if (mc.player != null && ClientPlayNetworking.canSend(SourceToggleAllPayload.TYPE)) {
            ClientPlayNetworking.send(new SourceToggleAllPayload((byte) kind, (byte) mode));
        }
    }

    public static void clearAllEmergency(Minecraft mc) {
        if (mc.player == null) return;
        int radius = mc.options.renderDistance().get() + 4;
        WaterWorld world = WaterWorld.get();

        for (Material m : Material.values()) {
            world.removeAll(radius, m);
        }
        sources(mc, 6, 0);

        mc.player.sendSystemMessage(Component.translatable("realistic-water.emergency.cleared"));
    }
}